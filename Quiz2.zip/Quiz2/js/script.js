/* Quiz Data */

const quiz = [
{
question:"Which language runs in browser?",
options:["Java","C","Python","JavaScript"],
answer:"JavaScript"
},
{
question:"What does CSS stand for?",
options:["Computer Style Sheets","Cascading Style Sheets","Creative Style System","Colorful Style Sheets"],
answer:"Cascading Style Sheets"
},
{
question:"Which HTML tag is used for JavaScript?",
options:["<js>","<javascript>","<script>","<code>"],
answer:"<script>"
},
{
question:"JavaScript object is used for?",
options:["Ordered list","Key-value pairs","Loops","Functions"],
answer:"Key-value pairs"
}
];

/* Random Questions */
quiz.sort(()=>Math.random()-0.5);

/* Variables */

let currentQuestion = 0;
let score = 0;
let timeLeft = 10;
let timer;
let userAnswers = new Array(quiz.length).fill(null);

/* Sounds */

/// Soothing correct sound (replace the old one)
const correctSound = new Audio("https://assets.mixkit.co/active_storage/sfx/2870/2870-preview.mp3");  // Soft gentle chime – recommended!

const wrongSound = new Audio("https://assets.mixkit.co/active_storage/sfx/2569/2569-preview.mp3");  // Bass buzzer – agar thoda strong chahiye

// Finish (celebration / party horn cheer)
const finishSound = new Audio("https://assets.mixkit.co/active_storage/sfx/2020/2020-preview.mp3");  

// Heartbeat (loop wala)
const heartbeatSound = new Audio("./sound/heartbeat.mp3");
heartbeatSound.loop = true;
heartbeatSound.volume = 0.6;


/* DOM */

const questionEl = document.getElementById("question");
const optionsEl = document.getElementById("options");
const nextBtn = document.getElementById("nextBtn");
const prevBtn = document.getElementById("prevBtn");
const feedbackEl = document.getElementById("feedback");
const progressEl = document.getElementById("progress");
const timerEl = document.getElementById("timer");

/* Timer */

function startTimer(){

clearInterval(timer);

timeLeft = 10;

if(timerEl) timerEl.textContent = timeLeft;

// Reset heartbeat
heartbeatSound.pause();
heartbeatSound.currentTime = 0;

timer = setInterval(()=>{

timeLeft--;

if(timerEl) timerEl.textContent = timeLeft;

// ❤️ Heartbeat last 5 sec
if(timeLeft <= 5 && timeLeft > 0){
heartbeatSound.play();
}

// ⏰ Time finish
if(timeLeft === 0){

heartbeatSound.pause();
heartbeatSound.currentTime = 0;

nextQuestion();
}

},1000);

}

/* Load Question */

function loadQuestion(){

startTimer();

const q = quiz[currentQuestion];

questionEl.textContent = q.question;
progressEl.textContent = `${currentQuestion+1}/${quiz.length}`;

optionsEl.innerHTML = "";

q.options.forEach(option => {

const btn = document.createElement("button");
btn.className = "btn btn-outline-primary option-btn";
btn.textContent = option;

btn.onclick = () => selectAnswer(option);

optionsEl.appendChild(btn);

});

nextBtn.disabled = true;
prevBtn.disabled = currentQuestion === 0;
}

/* Select Answer */

function selectAnswer(selected){

clearInterval(timer);

// Stop heartbeat
heartbeatSound.pause();
heartbeatSound.currentTime = 0;

userAnswers[currentQuestion] = selected;

[...optionsEl.children].forEach(btn=>{

btn.disabled = true;

if(btn.textContent === quiz[currentQuestion].answer){
btn.classList.add("correct");
}

if(btn.textContent === selected && selected !== quiz[currentQuestion].answer){
btn.classList.add("wrong");
}

});

if(selected === quiz[currentQuestion].answer){
score++;
feedbackEl.textContent = "Correct!";
correctSound.play();
}else{
feedbackEl.textContent = "Wrong!";
wrongSound.play();
}

nextBtn.disabled = false;
}

/* Navigation */

function nextQuestion(){

if(currentQuestion < quiz.length-1){
currentQuestion++;
feedbackEl.textContent = "";
loadQuestion();
}else{
showResult();
}
}

function prevQuestion(){

if(currentQuestion > 0){
currentQuestion--;
feedbackEl.textContent = "";
loadQuestion();
}
}

/* Rank System */

function getRank(){

let percent = (score/quiz.length)*100;

if(percent >= 90) return "Genius 🧠";
if(percent >= 70) return "Good 👍";
if(percent >= 50) return "Average 🙂";
return "Try Again 😅";
}

/* Result */

function showResult(){

finishSound.play();

document.querySelector(".card-body").innerHTML = `
<div class="text-center">
<h3>Quiz Completed 🎉</h3>
<h4>Your Score ${score}/${quiz.length}</h4>
<h5>${getRank()}</h5>
<button class="btn btn-success mt-3" onclick="location.reload()">Play Again</button>
</div>`;
}

/* Events */

nextBtn.onclick = nextQuestion;
prevBtn.onclick = prevQuestion;

/* Start */

loadQuestion();
